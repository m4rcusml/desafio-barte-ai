# Histórico de prompts: Raphael × Claude (preparação do pitch)

Sessão de 17/10/2026 no projeto "Casa Barte". Os prompts estão como foram escritos. Ao lado de cada um, um resumo curto do que a IA devolveu e do que foi feito com isso.

> A conversa completa e original está no link compartilhado da sessão: [colar aqui o link da conversa].

| # | Prompt (como foi escrito) | O que a IA devolveu / o que foi feito |
| --- | --- | --- |
| 1 | "Claude, você consegue alinhar com a identidade visual da Barte [barte.pagamentos](https://www.instagram.com/barte.pagamentos/#) Olhe no instagram e copie. Esse é o link com o slide da apresentação. Alinhe também com o pdf no seu contexto, utilize-o como fio condutor para a edição na apresentação." + [link do Google Slides] | Pediu acesso ao Google Slides e aplicou a paleta e a tipografia da Barte (vinho/rosa, Inter). Reorganizou o deck seguindo a anatomia de pitch do PDF. |
| 2 | "Pronto conectei e pedi a autorização." | Editou os slides direto no Google Slides e conferiu cada um pela miniatura. Corrigiu textos que estouravam a caixa depois da troca de fonte. |
| 3 | "Os slides estão alinhados com as perguntas do documento ? Tipo, elas cumprem os requisitos ?" | Comparou o deck com os 7 pontos que o pitch tem que cobrir nas instruções e apontou o que faltava ou estava fraco. |
| 4 | "Voce consegue adiantar os pontos que não precisam ainda ?" | Fez as correções que não dependiam de número (papéis da IA, uso em outubro, onde a solução falha, próximo mês). |
| 5 | (anexo com o resumo de números do time) "Aqui as informações adicionais." | Recalculou os números direto nos arquivos do data pack antes de colocar no deck. Achou erros no resumo: taxa de 2,29% que não existe, IDs de transação inexistentes (TX88444318, TX88424032) e o bruto da Atlas errado (262.435,00 em vez de 262.138,61). Usou só o que bateu, como a comissão da Bridge: R$ 11.769,74 em 109 linhas. |
| 6 | "O que seria esses erros no resumo ?" | Explicou cada erro com a linha de origem que mostrava o valor certo. |
| 7 | "Faça uma nova checagem para ver se você cometeu algum erro." | Achou dois erros próprios nos slides ("mesmos arquivos" e "Papéis previstos") e corrigiu. |
| 8 | (zip com a saída do código) "Aqui o fechamento completo." | Conferiu o deck contra os CSVs de saída. Corrigiu as divergências (2.995,11 → 3.016,37) e as pendências (68 → 187). Apontou problemas no código: classificação do extrato Aurora, referência das linhas do Aurora e a regra da bandeira. |
| 9 | "Faça para mim agora o último entregável que pede as pastas e afins." | Montou README, HIPOTESES, PROMPTS/MOMENTOS.md e saida/. |
| 10 | "Esses outros entregáveis fica com o marcus. O que eu preciso entregar para ele é somente o histórico nosso. Entende ?" | Orientou a usar o link da conversa como histórico. |
| 11 | "Como não w" (mensagem cortada) | Pediu para repetir a mensagem. |
| 12 | "Não, eu gostaria que você enviasse tudo que está no projeto da casa barte" | Juntou os arquivos do projeto. |
| 13 | "Todo o histórico nosso de conversa e prompts daqui desse projeto, pois é necessário." | Este arquivo. |
